import React from 'react'

function SubmitButton() {
    return (
        <button>Ask</button>     
    )
}
export default SubmitButton;

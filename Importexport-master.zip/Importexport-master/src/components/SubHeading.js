import React from 'react'

function SubHeading() {
    return (
        <h5>Happy to solve you doubts.</h5>
    )
}
export default SubHeading;

import React from 'react'

function InputQuery() {
    return (
        <input placeHolder={'Enter your query here..'} />
    )
}
export default InputQuery;
